# InstaBrute
# InstaBrute Two Ways to Brute-force Instagram Account Hacking

### what is a InstaBrute

### Instagram contained two distinct vulnerabilities that allowed an attacker to brute-force
### passwords of user accounts. Combined with user enumeration, a weak password policy
### no 2FA nor other mitigating security controls, this could have allowed an attacker to compromise 
### many accounts without any user interaction, including high-profile ones. 
### Facebook fixed both issues and awarded a combined bounty of $5.000.


### Download&install

### apt-get install tor

### git clone https://github.com/Ha3MrX/InstaBrute

### cd InstaBrute

### chmod +x insta.sh

### ./insta.sh

### screenshot

![capture](https://user-images.githubusercontent.com/33704360/39670422-5738279c-510d-11e8-9f6d-a8e24114a510.PNG)

### YouTube Channel

### https://www.youtube.com/c/HA-MRX

### Viddeo Tutorial

### https://www.youtube.com/watch?v=a-moMHuZX_Q&t=11s
